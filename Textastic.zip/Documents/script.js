// 질문과 답변 데이터
const questions = [
  {
    question: "당신의 성격을 한 단어로 표현한다면?",
    options: [
      { text: "활발하다", type: "시트러스" },
      { text: "사교적이다", type: "플로럴" },
      { text: "차분하다", type: "우디" },
      { text: "따뜻하다", type: "머스크" }
    ]
  },
  {
    question: "당신이 좋아하는 활동은?",
    options: [
      { text: "산책", type: "허브" },
      { text: "운동", type: "프루티" },
      { text: "요리", type: "바닐라" },
      { text: "독서", type: "레더" }
    ]
  },
  {
    question: "어떤 환경을 선호하나요?",
    options: [
      { text: "자연", type: "그린" },
      { text: "도시", type: "레더" },
      { text: "해변", type: "아쿠아" },
      { text: "산", type: "우디" }
    ]
  },
  {
    question: "하루 중 가장 집중이 잘 되는 시간은?",
    options: [
      { text: "아침 일찍", type: "시트러스" },
      { text: "오후 햇살", type: "플로럴" },
      { text: "노을 무렵", type: "우디" },
      { text: "밤의 정적", type: "머스크" }
    ]
  },
  {
    question: "당신이 좋아하는 공간은?",
    options: [
      { text: "햇살 드는 카페", type: "플로럴" },
      { text: "숲속 산책로", type: "허브" },
      { text: "예술 갤러리", type: "레더" },
      { text: "모던한 서재", type: "파우더리" }
    ]
  },
  {
    question: "여행지에서 가장 먼저 찾는 장소는?",
    options: [
      { text: "해변가", type: "아쿠아" },
      { text: "재래시장", type: "스파이시" },
      { text: "한적한 미술관", type: "레더" },
      { text: "풀숲 속 정원", type: "그린" }
    ]
  },
  {
    question: "지금 가장 끌리는 공간은?",
    options: [
      { text: "햇살이 드는 정원", type: "플로럴" },
      { text: "고요한 서재", type: "파우더리" },
      { text: "시원한 바닷가", type: "아쿠아" },
      { text: "울창한 숲 속", type: "그린" }
    ]
  },
  {
    question: "지금 기분을 색으로 표현한다면?",
    options: [
      { text: "밝은 옐로우", type: "시트러스" },
      { text: "포근한 베이지", type: "바닐라" },
      { text: "짙은 네이비", type: "레더" },
      { text: "투명한 블루", type: "머스크" }
    ]
  },
  {
    question: "하루의 끝, 당신은?",
    options: [
      { text: "감성적인 플레이리스트", type: "우디" },
      { text: "달콤한 간식과 담요", type: "바닐라" },
      { text: "책 한 권과 조용한 시간", type: "파우더리" },
      { text: "캔들과 잔잔한 음악", type: "머스크" }
    ]
  },
  {
    question: "가장 좋아하는 계절은?",
    options: [
      { text: "봄", type: "플로럴" },
      { text: "여름", type: "시트러스" },
      { text: "가을", type: "우디" },
      { text: "겨울", type: "머스크" }
    ]
  },
  {
    question: "자주 찾는 취미는 무엇인가요?",
    options: [
      { text: "그림 그리기", type: "플로럴" },
      { text: "독서", type: "파우더리" },
      { text: "음악 듣기", type: "시트러스" },
      { text: "자연 산책", type: "그린" }
    ]
  },
  {
    question: "아침에 일어나면 가장 먼저 하는 일은?",
    options: [
      { text: "커피 마시기", type: "머스크" },
      { text: "창 밖을 바라보기", type: "우디" },
      { text: "운동하기", type: "시트러스" },
      { text: "명상하기", type: "허브" }
    ]
  },
  {
    question: "자주 가는 카페 스타일은?",
    options: [
      { text: "햇살 가득한 카페", type: "플로럴" },
      { text: "고요한 분위기", type: "우디" },
      { text: "모던한 인테리어", type: "레더" },
      { text: "빈티지한 느낌", type: "파우더리" }
    ]
  },
  {
    question: "일상에서 편안함을 주는 요소는?",
    options: [
      { text: "따뜻한 햇살", type: "플로럴" },
      { text: "시원한 공기", type: "아쿠아" },
      { text: "고요한 분위기", type: "머스크" },
      { text: "자연의 소리", type: "허브" }
    ]
  },
  {
    question: "당신의 이상적인 휴식 방법은?",
    options: [
      { text: "조용한 장소에서 독서", type: "파우더리" },
      { text: "자연 속에서 산책", type: "그린" },
      { text: "친구들과 대화", type: "시트러스" },
      { text: "맛있는 음식과 함께 영화보기", type: "플로럴" }
    ]
  },
  {
    question: "가장 좋아하는 색은 무엇인가요?",
    options: [
      { text: "밝은 노란색", type: "시트러스" },
      { text: "연한 핑크", type: "플로럴" },
      { text: "따뜻한 갈색", type: "우디" },
      { text: "부드러운 회색", type: "파우더리" }
    ]
  },
  {
    question: "가장 좋아하는 음식은 무엇인가요?",
    options: [
      { text: "상큼한 과일", type: "시트러스" },
      { text: "디저트", type: "바닐라" },
      { text: "고기 요리", type: "레더" },
      { text: "신선한 채소", type: "그린" }
    ]
  },
  {
    question: "친구에게서 가장 중요한 점은 무엇인가요?",
    options: [
      { text: "솔직함", type: "시트러스" },
      { text: "따뜻함", type: "플로럴" },
      { text: "안정감", type: "우디" },
      { text: "독립성", type: "머스크" }
    ]
  },
  {
    question: "자신을 가장 잘 표현하는 단어는 무엇인가요?",
    options: [
      { text: "열정적", type: "시트러스" },
      { text: "감성적", type: "플로럴" },
      { text: "고요한", type: "우디" },
      { text: "실용적", type: "머스크" }
    ]
  },
  {
    question: "여행을 떠날 때, 가장 먼저 챙기는 것은?",
    options: [
      { text: "카메라", type: "시트러스" },
      { text: "책", type: "플로럴" },
      { text: "편안한 옷", type: "우디" },
      { text: "음악", type: "머스크" }
    ]
  },
  {
    question: "스트레스를 해소하는 방법은?",
    options: [
      { text: "운동", type: "시트러스" },
      { text: "음악 듣기", type: "플로럴" },
      { text: "혼자 있는 시간", type: "우디" },
      { text: "맛있는 음식을 먹기", type: "머스크" }
    ]
  },
  {
    question: "가장 좋아하는 영화 장르는?",
    options: [
      { text: "액션", type: "시트러스" },
      { text: "드라마", type: "플로럴" },
      { text: "미스터리", type: "우디" },
      { text: "다큐멘터리", type: "머스크" }
    ]
  },
  {
    question: "당신의 스타일을 가장 잘 표현하는 패션은?",
    options: [
      { text: "밝고 캐주얼", type: "시트러스" },
      { text: "섬세하고 우아함", type: "플로럴" },
      { text: "모던하고 시크", type: "레더" },
      { text: "편안한 느낌", type: "파우더리" }
    ]
  },
  {
    question: "좋아하는 음악 스타일은?",
    options: [
      { text: "경쾌한 팝", type: "시트러스" },
      { text: "잔잔한 클래식", type: "플로럴" },
      { text: "드럼과 베이스가 있는 록", type: "우디" },
      { text: "편안한 재즈", type: "머스크" }
    ]
  },
  {
    question: "일상에서 당신이 가장 선호하는 느낌은?",
    options: [
      { text: "상큼하고 활기찬", type: "시트러스" },
      { text: "부드럽고 따뜻한", type: "바닐라" },
      { text: "차분하고 안정적인", type: "우디" },
      { text: "강렬하고 매혹적인", type: "스파이시" }
    ]
  },
  {
    question: "어떤 음식을 더 좋아하나요?",
    options: [
      { text: "상큼한 과일", type: "프루티" },
      { text: "크림이 가득한 디저트", type: "바닐라" },
      { text: "향신료가 들어간 요리", type: "스파이시" },
      { text: "허브가 들어간 요리", type: "허브" }
    ]
  },
  {
    question: "친구와 함께할 때 어떤 활동을 선호하나요?",
    options: [
      { text: "활동적이고 에너지 넘치는", type: "시트러스" },
      { text: "편안하고 아늑한", type: "머스크" },
      { text: "자연을 느낄 수 있는", type: "허브" },
      { text: "예술적인 활동", type: "레더" }
    ]
  },
  {
    question: "휴식 시간에 어떤 음악을 듣나요?",
    options: [
      { text: "상쾌하고 활기찬", type: "시트러스" },
      { text: "차분하고 감성적인", type: "플로럴" },
      { text: "잔잔하고 평화로운", type: "우디" },
      { text: "고요하고 안락한", type: "머스크" }
    ]
  }
];


// 결과
const results = {
  "시트러스": {
    name: "활기찬 시트러스",
    desc: "상큼하고 신선한 에너지. 자몽, 베르가못, 라임 향과 잘 어울립니다.",
    img: "image/IMG_0287.jpg.PNG"
  },
  "플로럴": {
    name: "로맨틱한 플로럴",
    desc: "섬세하고 따뜻한 감성. 로즈, 미모사, 튤립 향과 어울려요.",
    img: "image/IMG_0288.jpg.PNG"
  },
  "우디": {
    name: "잔잔한 우디",
    desc: "고요한 숲의 잔향. 시더우드, 샌달우드, 파출리 향과 조화로워요.",
    img: "image/IMG_0289.jpg.PNG"
  },
  "머스크": {
    name: "포근한 머스크",
    desc: "부드럽고 안락한 인상. 화이트 머스크, 앰버, 머스크톤이 어울립니다.",
    img: "image/IMG_0290.jpg.PNG"
  },
  "프루티": {
    name: "발랄한 프루티",
    desc: "톡톡 튀는 매력. 복숭아, 망고, 베리류 향과 잘 맞습니다.",
    img: "image/IMG_0291.jpg.PNG"
  },
  "바닐라": {
    name: "달콤한 바닐라",
    desc: "따뜻하고 포근한 무드. 바닐라, 통카빈, 꿀 향과 잘 어울립니다.",
    img: "image/IMG_0292.jpg.PNG"
  },
  "레더": {
    name: "세련된 레더",
    desc: "감각적이고 시크한 무드. 스웨이드, 블랙티, 스모키 향과 조화로워요.",
    img: "image/IMG_0293.jpg.PNG"
  },
  "허브": {
    name: "내추럴한 허브",
    desc: "맑고 청량한 느낌. 라벤더, 유칼립투스, 바질 향과 어울려요.",
    img: "image/IMG_0294.jpg.PNG"
  },
  "아쿠아": {
    name: "상쾌한 아쿠아",
    desc: "바다처럼 시원하고 깨끗한 향. 마린 노트와 조화로워요.",
    img: "image/IMG_0295.jpg.PNG"
  },
  "파우더리": {
    name: "포근한 파우더리",
    desc: "부드럽고 정돈된 이미지. 베이비파우더, 아이리스와 잘 어울려요.",
    img: "image/IMG_0296.jpg.PNG"
  },
  "스파이시": {
    name: "매혹적인 스파이시",
    desc: "강렬하고 이국적인 향. 시나몬, 정향, 샤프란이 어울립니다.",
    img: "image/IMG_0297.jpg.PNG"
  },
  "그린": {
    name: "싱그러운 그린",
    desc: "자연의 숨결 같은 향. 풀잎, 무화과 잎, 티리프 노트와 어울립니다.",
    img: "image/IMG_0298.jpg.PNG"
  },
  
};

// 페이지 요소
const startButton = document.getElementById('start-button');
const startPage = document.getElementById('start-page');
const questionPage = document.getElementById('question-page');
const resultPage = document.getElementById('result-page');
const questionText = document.getElementById('question-text');
const answerOptions = document.getElementById('answer-options');
const resultName = document.getElementById('result-name');
const resultDesc = document.getElementById('result-desc');
const resultImage = document.getElementById('result-image');
const shareButton = document.getElementById('share-button');

let currentQuestion = 0;
let selectedType = "";

// 시작하기 버튼 클릭
startButton.addEventListener('click', () => {
  startPage.style.display = 'none';
  questionPage.style.display = 'block';
  loadQuestion();
});

// 질문 불러오기
function loadQuestion() {
  const question = questions[currentQuestion];
  questionText.textContent = question.question;
  answerOptions.innerHTML = '';  // 기존 답변 옵션 비우기

  question.options.forEach(option => {
    const button = document.createElement('button');
    button.classList.add('option');
    button.textContent = option.text;
    button.addEventListener('click', () => {
      selectedType = option.type;
      currentQuestion++;

      if (currentQuestion < questions.length) {
        loadQuestion();
      } else {
        showResult();
      }
    });
    answerOptions.appendChild(button);
  });
}

// 결과 표시
function showResult() {
  const result = results[selectedType];
  resultName.textContent = result.name;
  resultDesc.textContent = result.desc;
  resultImage.innerHTML = `<img src="${result.img}" alt="${result.name}">`;

  questionPage.style.display = 'none';
  resultPage.style.display = 'block';
}

// 인스타그램 공유
shareButton.addEventListener('click', () => {
  const instagramUrl = `https://www.instagram.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`;
  window.open(instagramUrl, '_blank');
});
